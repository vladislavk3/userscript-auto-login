// ==UserScript==
// @name         Auto login script
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  try to take over the world!
// @author       You
// @match        https://login.microsoftonline.com/common/*
// @match        https://rdweb.wvd.microsoft.com/arm/webclient/*
// @grant        none
// @require      http://code.jquery.com/jquery-latest.js
// @require      file:///home/dev/Downloads/auto-login.js
// ==/UserScript==

(function() {
    'use strict';

})();