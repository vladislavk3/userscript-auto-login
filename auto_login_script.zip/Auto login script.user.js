// ==UserScript==
// @name         Auto login script
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://login.microsoftonline.com/common/*
// @grant        none
// @require http://code.jquery.com/jquery-latest.js
// ==/UserScript==

(function() {
    'use strict';

    $(document).ready(function() {
        if ( ! /\bresource=https%3A%2F%2Fwww.wvd.microsoft.com\b/.test (location.search) ) {
            setTimeout(function(){
                document.getElementById("idBtn_Back").click();
            }, 2000);
        };

        setTimeout(function(){
            document.getElementById("i0116").value = '800008@alseducation.onmicrosoft.com';
            document.getElementById("i0116").blur();
            document.getElementById("idSIButton9").setAttribute("onclick", "setTimeout(function(){ document.getElementById('i0118').value = 'tt060600'; document.getElementById('i0118').blur(); document.getElementById('i0118').focus(); document.getElementById('idSIButton9').click(); }, 3000);");
            setTimeout(function(){
                document.getElementById("idSIButton9").click();
            }, 2000);
        }, 3000);
    });
})();