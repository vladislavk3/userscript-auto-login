// ==UserScript==
// @name         Auto login script
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://login.microsoftonline.com/common/oauth2/*
// @grant        none
// @require http://code.jquery.com/jquery-latest.js
// ==/UserScript==

(function() {
    'use strict';

    $(document).ready(function() {
        if ( ! /\bclient_id=a85cf173-4192-42f8-81fa-777a763e6e2c\b/.test (location.search) ) return;

        setTimeout(function(){
            document.getElementById("i0116").value = '800008@alseducation.onmicrosoft.com';
            document.getElementById("idSIButton9").setAttribute("onclick", "setTimeout(function(){ document.getElementById('i0118').value = 'tt060600'; }, 2000);");
            document.getElementById("i0116").focus();
        }, 2000);
    });
})();